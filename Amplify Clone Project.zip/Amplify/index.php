<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spotify - Your favourite music is here</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav>
        <ul>
            <li class="brand"><img src="logo.png" alt="Amplify"> Amplify</li>
            
        
        
            <div class="rightNav">
                <!-- <input type="text" name="search" id="search"> -->
                <a href="log.php">
                    <button class="btn">Log-in
    
                    </button>
                </a>
            </div>

        </ul>

    </nav>

    <div class="container">
        <div class="songList">
            <h1>Best Songs - No Copyright Sounds</h1>
            <div class="songItemContainer">
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Why_This_Kolaveri_Di</span>
                    <span class="songlistplay"><span class="timestamp">04:08 <i id="0"
                                class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="2">
                    <span class="songName">Blue_Eyes</span>
                    <span class="songlistplay"><span class="timestamp">04:02 <i id="1"
                                class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="3">
                    <span class="songName">Chaar_Botal_Vodka</span>
                    <span class="songlistplay"><span class="timestamp">03:49 <i id="2"
                                class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="4">
                    <span class="songName">HOOKAH_BAR</span>
                    <span class="songlistplay"><span class="timestamp">04:10 <i id="3"
                                class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="5">
                    <span class="songName">Amplifier</span>
                    <span class="songlistplay"><span class="timestamp">03:52 <i id="4"
                                class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="6">
                    <span class="songName">Jo_Tu_Na_Mila</span>
                    <span class="songlistplay"><span class="timestamp">03:56 <i id="5"
                                class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                
            </div>
        </div>
        <div class="songBanner"></div>
    </div>

    <div class="bottom">
        <input type="range" name="range" id="myProgressBar" min="0" value="0" max="100">
        <div class="icons">
            <!-- fontawesome icons -->
            <i class="fas fa-3x fa-step-backward" id="previous"></i>
            <i class="far fa-3x fa-play-circle" id="masterPlay"></i>
            <i class="fas fa-3x fa-step-forward" id="next"></i>
        </div>
        <div class="songInfo">
            <img src="playing.gif" width="42px" alt="" id="gif"> <span id="masterSongName">Select Song</span>
        </div>
    </div>
    <script src="java.js"></script>
    <script src="https://kit.fontawesome.com/fc9c201d96.js" crossorigin="anonymous"></script>
</body>

</html>